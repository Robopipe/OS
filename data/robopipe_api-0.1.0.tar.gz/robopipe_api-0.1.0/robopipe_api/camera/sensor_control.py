import depthai as dai

import dataclasses
from enum import Enum
import math


@dataclasses.dataclass
class SensorControl:
    exposure_time: int
    sensitivity_iso: int
    auto_exposure_enable: bool
    auto_exposure_compensation: int
    auto_exposure_limit: int
    auto_exposure_lock: bool
    contrast: int
    brightness: int
    saturation: int
    chroma_denoise: int
    luma_denoise: int

    @classmethod
    def from_camera_control(cls, ctrl: dai.CameraControl):
        raw_ctrl = ctrl.get()
        properties = {
            "contrast": raw_ctrl.contrast,
            "brightness": raw_ctrl.brightness,
            "saturation": raw_ctrl.saturation,
            "chroma_denoise": raw_ctrl.chromaDenoise,
            "luma_denoise": raw_ctrl.lumaDenoise,
            "exposure_time": math.floor(ctrl.getExposureTime().total_seconds() * 1000),
            "sensitivity_iso": ctrl.getSensitivity(),
            "auto_exposure_enable": ctrl.getExposureTime().total_seconds() == 0,
            "auto_exposure_limit": raw_ctrl.aeMaxExposureTimeUs,
            "auto_exposure_compensation": raw_ctrl.expCompensation,
            "auto_exposure_lock": raw_ctrl.aeLockMode,
        }

        return cls(**properties)

    def to_camera_control(self) -> dai.CameraControl:
        ctrl = dai.CameraControl()
        ctrl.setContrast(self.contrast)
        ctrl.setBrightness(self.brightness)
        ctrl.setSaturation(self.saturation)
        ctrl.setChromaDenoise(self.chroma_denoise)
        ctrl.setLumaDenoise(self.luma_denoise)

        if self.auto_exposure_enable:
            ctrl.setAutoExposureEnable()
            ctrl.setAutoExposureLimit(self.auto_exposure_limit)
            ctrl.setAutoExposureCompensation(self.auto_exposure_compensation)
            ctrl.setAutoExposureLock(self.auto_exposure_lock)
        elif self.exposure_time > 0:
            ctrl.setManualExposure(self.exposure_time, self.sensitivity_iso)

        return ctrl


class AutoFocusMode(Enum):
    OFF = dai.CameraControl.AutoFocusMode.OFF.name
    AUTO = dai.CameraControl.AutoFocusMode.AUTO.name
    MACRO = dai.CameraControl.AutoFocusMode.MACRO.name
    CONTINUOUS_VIDEO = dai.CameraControl.AutoFocusMode.CONTINUOUS_VIDEO.name
    CONTINUOUS_PICTURE = dai.CameraControl.AutoFocusMode.CONTINUOUS_PICTURE.name
    EDOF = dai.CameraControl.AutoFocusMode.EDOF.name

    @classmethod
    def from_dai_af_mode(cls, af_mode: dai.CameraControl.AutoFocusMode):
        return cls(af_mode.name)

    def to_dai_af_mode(self) -> dai.CameraControl.AutoFocusMode:
        return dai.CameraControl.AutoFocusMode.__members__[self.name]


@dataclasses.dataclass
class SensorControlAF(SensorControl):
    auto_focus_mode: AutoFocusMode
    auto_focus_trigger: bool = False
    auto_focus_region: tuple[int, int, int, int] | None = None

    @classmethod
    def from_camera_control(cls, ctrl: dai.CameraControl):
        sensor_control = SensorControl.from_camera_control(ctrl)
        raw_ctrl = ctrl.get()

        return cls(
            **sensor_control,
            auto_focus_mode=AutoFocusMode.from_dai_af_mode(raw_ctrl.autoFocusMode),
        )

    def to_camera_control(self):
        ctrl = super().to_camera_control()
        ctrl.setAutoFocusMode(self.auto_focus_mode.to_dai_af_mode())
        ctrl.setAutoFocusTrigger(self.auto_focus_trigger)

        if self.auto_focus_region is not None:
            ctrl.setAutoFocusRegion(*self.auto_focus_region)
