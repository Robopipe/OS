import sys
from .robopipe import main

sys.exit(main())
