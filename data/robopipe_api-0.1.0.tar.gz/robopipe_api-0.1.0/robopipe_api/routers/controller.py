from fastapi import APIRouter

from .common import DevicesDep
from ..controller.devices import (
    num_to_devtype_name,
    DI,
    RO,
    DO,
    AI,
    AO,
    SENSOR,
    LED,
    WATCHDOG,
    MODBUS_SLAVE,
    OWPOWER,
    REGISTER,
    DATA_POINT,
    OWBUS,
    DEVICE_INFO,
)

router = APIRouter(prefix="/controller", tags=["controller"])


@router.get("/")
def get_all_circuits(devices: DevicesDep):
    DEVICE_TYPES = [
        DI,
        RO,
        DO,
        AI,
        AO,
        SENSOR,
        LED,
        WATCHDOG,
        MODBUS_SLAVE,
        OWPOWER,
        REGISTER,
        DATA_POINT,
        OWBUS,
        DEVICE_INFO,
    ]
    res = [
        device.full()
        for dev_type in DEVICE_TYPES
        for device in devices.by_int(dev_type)
    ]

    return res


device_router = APIRouter(prefix="/controller/{device_type}", tags=["controller"])


@device_router.get("/")
def get_all_devices_by_device_type(devices: DevicesDep, device_type: str):
    return [device.full() for device in devices.by_int(device_type)]


led_router = APIRouter(prefix="/controller/led/{circuit}", tags=["controller"])


@led_router.get("/")
def get_led_value(devices: DevicesDep, circuit: str):
    return devices.by_name("led", circuit).full()


@led_router.post("/")
async def set_led_value(devices: DevicesDep, circuit: str, value: str | int | bool):
    device = devices.by_name("led", circuit)
    await device.set(value)

    return device.full()


router.include_router(device_router)
router.include_router(led_router)
