from dataclasses import dataclass


@dataclass
class Device:
    dev: str
    circuit: str
