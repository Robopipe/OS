import logging

UVICORN_LOGGER = "uvicorn.error"

logger = logging.getLogger(UVICORN_LOGGER)
